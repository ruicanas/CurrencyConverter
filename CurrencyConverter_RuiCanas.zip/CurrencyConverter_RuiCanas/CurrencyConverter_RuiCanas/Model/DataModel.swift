//
//  DataModel.swift
//  CurrencyConverter_RuiCanas
//
//  Created by itsector on 07/04/2021.
//

import UIKit

class DataModel{
    
}
